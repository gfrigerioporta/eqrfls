function [eqc] = eq_maker2(d,m,t,alp,bet,nd)
%Funciton to calcualte the earthquake contributions
m(m~=0) = 10.^(alp.*(m(m~=0)-3));
d(d~=0) = (d(d~=0).^bet);
m(m~=0) = m(m~=0)./d(d~=0);

m = [t'; m];

ut = unique (t);
eqc = [0:nd-1; zeros(size(d,1),nd)];
eqc(2:size(eqc,1),eqc(1,:)==ut(1))=sum(m(2:size(m,1),m(1,:)==ut(1)),2);
for i=2:size(ut)
    
    eqc(2:size(eqc,1),eqc(1,:)==ut(i))=sum(m(2:size(m,1),m(1,:)==ut(i) | m(1,:)==ut(i-1)),2);
end