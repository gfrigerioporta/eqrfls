function [ vecform ] = m2rv(x)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here

temp = size(x);
k = temp(1);
vecform = 1:0;
for i = 1:k
    vecform = [vecform x(i,:)];
end

end

