% calc_mu.m
mu1 = exp(best_x(1));
mu2 = exp(best_x(2));
mu2=0.2013;
mu3 = exp(best_x(3));
nu0 = best_x(4);
%select nu form and initialise any extra parameters depending of nu_form
if nu_form == 0
    nu = nu0*ones(size(rf1,1),size(rf1,2));
else
    if nu_form == 1
        nu1 = best_x(5);
        nu = nu0 + nu1 * rf1;
    else
        if nu_form == 2
            nu2 = best_x(5);
            nu = nu0 + nu2 * rf2;
        else
            nu1 = best_x(5);
            nu2 = best_x(6);
            nu3 = best_x(7);
            nu = nu0 + nu1 * rf1 + nu2 * rf2 + nu3 * eqc;
        end
    end
end

p = exp(-nu)./(1+exp(-nu));
p(isnan(p))=0.001;
if mult_model == 2
    logmu0 = mu1 * rf1 + mu2 * rf2 + mu3 * eqc;%matrix (x,t)
else
    if mult_model == 1
        logmu0 = log(exp(mu1 * rf1) + exp(mu2 * rf2) + exp(mu3 * eqc));
    else
        if mult_model == 3
            logmu0 = log(exp(mu1 * rf1 + mu2 * rf2) + exp(mu3 * eqc + mu2 * rf2));%matrix (x,t)  
        end
    end
end
mutemp = (1-p).*exp(logmu0); %matrix (x,t)
mudash = mutemp';
lsdash = best_ls';    % GET EM SOLN FOR LS DAYS
mu0 = sum(lsdash)./sum(mudash);
%calculation of mu
mu = mu0*mutemp;

% mu = (mu0'*ones(1,length(mutemp))).*mutemp;